package cn.itcast.chapter07.javabean;
public class Book {
	private double price;
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}
