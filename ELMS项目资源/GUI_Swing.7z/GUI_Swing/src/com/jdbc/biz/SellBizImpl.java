/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.dao.BaseDao;
import com.jdbc.dao.ProductDao;
import com.jdbc.dao.SellDao;
import com.jdbc.po.Sell;
import com.jdbc.po.Year;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class SellBizImpl implements ISellBiz {

    SellDao sdao = new SellDao();
    ProductDao prodao = new ProductDao();

    @Override
    public List<Sell> findAll() {
        String sql = "select * from t_sell se left join t_product pro on se.proid = pro.proid left join t_customer cus on "
                + "se.cusid = cus.cusid left join t_employee emp on se.uid = emp.uid ORDER BY selldate desc";
        Object[] params = {};
        return sdao.query(sql, Sell.class, params);
    }

    @Override
    public List<Sell> findByKey(String start, String end, String key) {
        String sql = "select * from t_sell se left join t_product pro on se.proid = pro.proid left join t_customer cus on "
                + "se.cusid = cus.cusid left join t_employee emp on se.uid = emp.uid  where  selldate between ? and ? "
                + "and concat(pro.proname,emp.truename,sellprice) like ? ORDER BY selldate desc";
        Object[] params = {start, end, "%" + key + "%"};
        return sdao.query(sql, Sell.class, params);
    }

    @Override
    public boolean addSell(Object[][] purchases, Object[][] stocks) {
        boolean result = true;
        String sql1 = "insert into t_sell(seid,proid,cusid,uid,sellprice,sellnum,selldate) values(?,?,?,?,?,?,?)";
        String sql2 = "update t_product set quantity = quantity - ? where proid=?";//库存增加
        Connection conn = new BaseDao().getConnection();//获得连接     
        try {
            conn.setAutoCommit(false);//设置不自动提交
            sdao.batchUpdate(conn, sql1, purchases);//批量添加销售表
            prodao.batchUpdate(conn, sql2, stocks);//更新商品库存
            conn.commit();     //提交事务
        } catch (Exception e) {
            try {
                result = false;
                conn.rollback(); //回滚事务
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean updateSell(String seid, int proid, int returnnum, Date returntime) {
        boolean result = true;
        //修改采购表的退货数量和退货时间
        String sql1 = "update t_sell set sellreturnamount=?,sellreturndate=?,sellnum=sellnum-? where seid=?";
        Object[] params1 = {returnnum, returntime, returnnum, seid};
        String sql2 = "update t_product set quantity= quantity+?  where proid=?";
        Object[] params2 = {returnnum, proid};
        Connection conn = new BaseDao().getConnection();
        try {
            conn.setAutoCommit(false);//启动事务
            sdao.update(conn, sql1, params1);
            prodao.update(conn, sql2, params2);
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                result = false;
                conn.rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    @Override
    public List<Sell> findByCusid(String start, String end) {
        String sql = "SELECT cus.cusid,cusname,SUM(sellprice) price from t_sell se left join t_customer cus "
                + "on se.cusid = cus.cusid ";
        if(start != null && end != null){
            sql +=" where selldate between '"+start+"' and '"+ end+"'";
        }
        sql +=" GROUP BY cus.cusid ORDER BY selldate desc";
        Object[] params = {};
        return sdao.query(sql, Sell.class, params);
    }

    @Override
    public List<Year> getYear() {
       String sql= "SELECT DISTINCT YEAR(selldate) as puryear from t_sell";
        Object[] params = {};
        List<Year> query = sdao.query(sql, Year.class, params);
        return query;
    }

    @Override
    public List<Sell> getByEmp(String start,String end) {
        String sql= "SELECT emp.uid,truename,SUM(sellnum*sellprice) countmoney from t_employee emp "
                + "LEFT JOIN t_sell se on emp.uid = se.uid "
                + "WHERE selldate between ? and ? GROUP BY emp.uid ORDER BY countmoney DESC limit 0,10";
        Object[] params = {start,end};
        return sdao.query(sql, Sell.class, params);
    }

    @Override
    public List<Sell> getByCusid(int cusid) {
       String sql="select * from t_sell where cusid = ? and state = 1";
       Object[] params = {cusid};
       return sdao.query(sql,Sell.class, params);
    }
}
