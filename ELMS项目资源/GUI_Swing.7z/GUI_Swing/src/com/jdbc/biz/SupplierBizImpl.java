/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.dao.SupplierDao;
import com.jdbc.po.Product;
import com.jdbc.po.Supplier;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class SupplierBizImpl implements ISupplierBiz{
    SupplierDao sdao = new SupplierDao();
    @Override
    public List<Supplier> findAll() {
        String sql = "select * from t_supplier where state = 1";
        Object[] params={};
        return sdao.query(sql, Supplier.class, params);
    }

    @Override
    public boolean addProduct(Supplier sup) {
        String sql = "insert into t_supplier values(?,?,?,?,?,?,?,1)"; 
        Object[] params = {sup.getSupid(),sup.getSupaddreviation(),sup.getSupfullname(),sup.getOwmer(),sup.getModile(),sup.getJob(),sup.getSupaddress()};
        return sdao.update(sql, params);
    }

    @Override
    public boolean updateProduct(Supplier sup) {
        String sql = "update t_supplier set supaddreviation=?,supfullname = ?,owmer=?,job=?,modile=?,supaddress=? where supid=?"; 
        Object[] params = {sup.getSupaddreviation(),sup.getSupfullname(),sup.getOwmer(),sup.getJob(),sup.getModile(),sup.getSupaddress(),sup.getSupid()};
        return sdao.update(sql, params);
    }

    @Override
    public boolean deleteSupplier(int id) {
        String sql = "update t_supplier set state=-1 where supid=?"; 
        Object[] params = {id};
        return sdao.update(sql, params);
    }
    
}
