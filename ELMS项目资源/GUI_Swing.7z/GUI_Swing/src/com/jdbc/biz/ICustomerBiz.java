/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.po.Customer;
import com.jdbc.po.Supplier;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ICustomerBiz {
    public List<Customer> findAll(String key);
    public boolean addCustomer(Customer cus);
    public boolean updateCustomer(Customer cus);
    public boolean deleteCustomer(int id);
    public List<Customer> getByUid(int uid);
    }
