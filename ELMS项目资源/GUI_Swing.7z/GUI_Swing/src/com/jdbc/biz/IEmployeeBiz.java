/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.po.Employee;
import com.jdbc.po.Product;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface IEmployeeBiz {
    public List<Employee> findAll(String key);
    public boolean addProduct(Employee e);
    public boolean updateEmployee(Employee e);
    public boolean deleteEmployee(int id);
    public Employee checkEmployee(String username,String password);
    public Employee getByUid(String id);
    public Employee getByUsername(String username);
}
