/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.dao.CustomerDao;
import com.jdbc.po.Customer;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class CustomerBizImpl implements ICustomerBiz{
    CustomerDao cdao = new CustomerDao();
    @Override
    public List<Customer> findAll(String key) {
        String sql = "select * from t_customer cus left join t_employee emp on cus.uid = emp.uid where cus.state = 1";
        if(key != null && key.length()>0){
            sql += "and concat(cusname,taobaoid,cus.uid) like %"+key+"% ";
        }
        Object[] params={};
        return cdao.query(sql, Customer.class, params);
    }

    @Override
    public boolean addCustomer(Customer cus) {
        String sql = "insert into t_customer values(?,?,?,?,?,?,?,null,1)"; 
        Object[] params = {cus.getCusid(),cus.getUid(),cus.getCusname(),cus.getTaobaoid(),cus.getCusphone(),cus.getPostcard(),cus.getCusaddress()};
        return cdao.update(sql, params);
    }

    @Override
    public boolean updateCustomer(Customer cus) {
        String sql = "update t_customer set uid = ?,cusname=?,taobaoid=?,cusphone=?,postcard=?,cusaddress=? where cusid=?"; 
        Object[] params = {cus.getUid(),cus.getCusname(),cus.getTaobaoid(),cus.getCusphone(),cus.getPostcard(),cus.getCusaddress(),cus.getCusid()};
        return cdao.update(sql, params);
    }

    @Override
    public boolean deleteCustomer(int id) {
        String sql = "update t_customer set state=-1 where cusid=?"; 
        Object[] params = {id};
        return cdao.update(sql, params);
    }

    @Override
    public List<Customer> getByUid(int uid) {
        String sql = "select * from t_customer where uid = ? and state = 1";
        Object[] params={uid};
        return cdao.query(sql, Customer.class, params);
    }
    
}
