/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.dao.BaseDao;
import com.jdbc.dao.ProductDao;
import com.jdbc.dao.PurchaseDao;
import com.jdbc.po.Purchase;
import com.jdbc.po.Year;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class PurchaseBizImpl implements IPurchaseBiz {

    ProductDao prodao = new ProductDao();
    PurchaseDao purdao = new PurchaseDao();

    @Override
    public boolean deletePurchase(int id) {
        String sql = "detele from t_purchase where purid = ?";
        Object[] params = {id};
        return purdao.update(sql, params);
    }

    @Override
    public List<Purchase> getByPurchase(String start, String end, String key) {
        String sql = "select * from t_purchase pur left join t_product pro on pur.proid = pro.proid left join "
                + "t_supplier sup on sup.supid = pur.supid where purdate between ? and ? and concat(supfullname,proname) like ?";
        Object[] params = {start, end, "%" + key + "%"};
        return purdao.query(sql, Purchase.class, params);
    }

    @Override
    public List<Purchase> findAll() {
        String sql = "select * from t_purchase pur left join t_product pro on pur.proid = pro.proid left join "
                + "t_supplier sup on sup.supid = pur.supid";
        Object[] params = {};
        return purdao.query(sql, Purchase.class, params);
    }

    @Override
    public boolean purchasein(Object[][] purchases, Object[][] stocks) {
        boolean result = true;
        String sql1 = "insert into t_purchase(purid,proid,supid,purprice,purnumber,unit,totalmoney,purdate) values(?,?,?,?,?,?,?,?)";
        String sql2 = "update t_product set quantity = quantity + ? where proid=?";//库存增加
        Connection conn = new BaseDao().getConnection();//获得连接     
        try {
            conn.setAutoCommit(false);//设置不自动提交
            purdao.batchUpdate(conn, sql1, purchases);//批量添加采购表
            prodao.batchUpdate(conn, sql2, stocks);//更新商品库存
            conn.commit();     //提交事务
        } catch (Exception e) {
            try {
                result = false;
                conn.rollback(); //回滚事务
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return result;

    }

    @Override
    public boolean purchasereturn(String purid, int proid, int returnnum, Date returntime, String returnreason) {
        boolean result = true;
        //修改采购表的退货数量和退货时间
        String sql1 = "update t_purchase set returnamount=?,returndate=?,purnumber=purnumber-? ,returnreason=?,totalmoney=totalmoney-(?*purprice)where purid=?";
        Object[] params1 = {returnnum, returntime, returnnum, returnreason, returnnum, purid};
        String sql2 = "update t_product set quantity= quantity-?  where proid=?";
        Object[] params2 = {returnnum, proid};
        Connection conn = new BaseDao().getConnection();
        try {
            conn.setAutoCommit(false);//启动事务
            boolean update = purdao.update(conn, sql1, params1);
            boolean update1 = prodao.update(conn, sql2, params2);
            conn.commit();
        } catch (Exception e) {
            try {
                result = false;
                conn.rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    @Override
    public List<Purchase> findSup(String start, String end, String key, String sort) {
        String sql = "SELECT pur.supid,supfullname,proname,SUM(purnumber) countnum,sum(totalmoney) countmoney from t_purchase pur "
                + "LEFT JOIN t_product pro on pur.proid=pro.proid LEFT JOIN t_supplier sup on pur.supid = sup.supid "
                + "where concat(supfullname,proname)like ? ";
        if (start != null && end != null) {
            sql += "and purdate between '"+start+"' and '"+end+"'";
        }
        sql += " GROUP BY pur.supid ORDER BY " + sort;
        Object[] params = { "%" + key + "%"};
        return purdao.query(sql, Purchase.class, params);
    }

    @Override
    public List<Year> getYear() {
        String sql= "SELECT DISTINCT YEAR(purdate) as puryear from t_purchase";
        Object[] params = {};
        List<Year> query = purdao.query(sql, Year.class, params);
        return query;
    }

    @Override
    public List<Purchase> getByPro(String start, String end) {
        String sql = "select pro.proid,proname,protype,protype,SUM(purnumber) countnum,SUM(totalmoney) countmoney from t_product pro "
                + "LEFT JOIN t_purchase pur on pro.proid = pur.proid "
                + "where purdate between ? and ? GROUP BY pro.proid ORDER BY countmoney DESC";
        Object[] params = {start,end};
        return purdao.query(sql, Purchase.class, params);
    }

    @Override
    public List<Purchase> getBySup(String start, String end) {
        String sql = "SELECT pur.supid,supfullname,sum(totalmoney) countmoney from t_supplier sup  "
                + "LEFT JOIN t_purchase pur on pur.supid = sup.supid  "
                + "where purdate between ? and ? "
                + "GROUP BY pur.supid ORDER BY countmoney DESC";
        Object[] params = {start,end};
        return purdao.query(sql, Purchase.class, params);
    }

    @Override
    public List<Purchase> getBySupAndPro(String start, String end) {
        String sql = "SELECT pur.supid,pur.proid,supfullname,proname,protype,unit,SUM(purnumber) countnum,sum(totalmoney) countmoney from t_purchase pur "
                + "LEFT JOIN t_supplier sup on pur.supid = sup.supid LEFT JOIN t_product pro on pur.proid=pro.proid "
                + "where  purdate between ? and ? GROUP BY pur.supid,pro.proid ORDER BY pur.supid,countmoney DESC";
        Object[] params = {start,end};
        return purdao.query(sql, Purchase.class, params);
    }

    @Override
    public List<Purchase> getByProAndSup(String start, String end) {
       String sql = "SELECT pur.supid,pur.proid,supfullname,proname,protype,unit,SUM(purnumber) countnum,sum(totalmoney) countmoney from t_purchase pur "
                + "LEFT JOIN t_supplier sup on pur.supid = sup.supid LEFT JOIN t_product pro on pur.proid=pro.proid "
                + "where  purdate between ? and ? GROUP BY pro.proid,pur.supid  ORDER BY pur.proid,countmoney DESC";
        Object[] params = {start,end};
        return purdao.query(sql, Purchase.class, params);
    }
    

}
