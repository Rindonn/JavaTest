/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.dao.EmployeeDao;
import com.jdbc.po.Employee;
import com.jdbc.view.MainJFrame;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class EmployeeBizImpl implements IEmployeeBiz {

    EmployeeDao edao = new EmployeeDao();

    @Override
    public List<Employee> findAll(String key) {
        String sql = "select * from t_employee where state = 1 and concat(username,truename) like ?";
        Object[] params = {"%" + key + "%"};
        return edao.query(sql, Employee.class, params);
    }

    @Override
    public boolean addProduct(Employee e) {
        String sql = "insert into t_employee values(?,?,?,?,?,?,?,?)";
        Object[] params = {e.getUid(), e.getUsername(), e.getPassword(), e.getTruename(), e.getPosition(), e.getPhone(), e.getCid(), 1};
        return edao.update(sql, params);
    }

    @Override
    public boolean updateEmployee(Employee e) {
        String sql = "update t_employee set  username=?,password=?,truename=?,position=?,phone=?,cid = ? where uid=?";
        Object[] params = {e.getUsername(), e.getPassword(), e.getTruename(), e.getPosition(), e.getPhone(), e.getCid(), e.getUid()};
        return edao.update(sql, params);
    }

    @Override
    public boolean deleteEmployee(int id) {
        String sql = "update t_employee set state=-1 where uid = ?";
        Object[] params = {id};
        return edao.update(sql, params);
    }

    @Override
    public Employee checkEmployee(String username, String password) {
        String sql = "select * from t_employee where username = ? and password=? and state = 1";
        Object[] params = {username, password};
        Employee e = (Employee) edao.get(sql, Employee.class, params);
        MainJFrame.emp = e;
        return e;
    }

    @Override
    public Employee getByUid(String id) {
        String sql = "select * from t_employee where uid = ?";
        Object[] params = {id};
        return (Employee) edao.get(sql, Employee.class, params);
    }

    @Override
    public Employee getByUsername(String username) {
        String sql = "select * from t_employee where username = ? and state = 1";
        Object[] params = {username};
        return (Employee) edao.get(sql, Employee.class, params);
    }

}
