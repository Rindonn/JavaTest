/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.po;

/**
 *
 * @author Administrator
 */
public class Year {
    private String puryear;

    public String getPuryear() {
        return puryear;
    }

    public void setPuryear(String puryear) {
        this.puryear = puryear;
    }
    
}
