/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.po.Product;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface IProductBiz {
    public List<Product> findAll(String key);
    public boolean addProduct(Product p);
    public boolean updateProduct(Product p);
    public boolean deleteProduct(int id);
    public Product checkProduct(String name,String type);
    public Product getByPid(String id);
}
