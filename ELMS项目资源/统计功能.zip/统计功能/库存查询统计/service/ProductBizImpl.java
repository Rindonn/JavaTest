/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.dao.ProductDao;
import com.jdbc.po.Product;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class ProductBizImpl implements IProductBiz{
    ProductDao pdao = new ProductDao();
    @Override
    public List<Product> findAll(String key) {
      String sql = "select * from t_product where concat(proname,protype) like ? and state = 1";
      Object[] params={"%"+key+"%"};
      return pdao.query(sql, Product.class, params);
    }

    @Override
    public boolean addProduct(Product p) {
       String sql = "insert into t_product values(?,?,?,?,?,?,?,?,?,1)"; 
       Object[] params = {p.getProid(),p.getProname(),p.getProtype(),p.getStorecount(),p.getQuantity(),p.getSuggestbuyprice(),p.getSuggestsaleprice(),null,null};
       return pdao.update(sql, params);
    }

    @Override
    public boolean updateProduct(Product p) {
       String sql = "update t_product set proname=?,protype = ?,storecount=?,quantity=?,suggestbuyprice=?,suggestsaleprice=? where proid=?";
       Object[] params = {p.getProname(),p.getProtype(),p.getStorecount(),p.getQuantity(),p.getSuggestbuyprice(),p.getSuggestsaleprice(),p.getProid()};
       return pdao.update(sql, params);
    }

    @Override
    public boolean deleteProduct(int id) {
       String sql = "update t_product set state=-1 where proid=?";
       Object[] params = {id};
       return pdao.update(sql, params);
    }

    @Override
    public Product checkProduct(String name,String type) {
      String sql = "select * from t_product where proname = ? and protype = ?";
      Object[] params = {name,type};
      return (Product) pdao.get(sql, Product.class, params);
    }

    @Override
    public Product getByPid(String id) {
        String sql = "select * from t_product where proid = ?";
        Object[] params = {id};
         return (Product) pdao.get(sql, Product.class, params);
    }
}
