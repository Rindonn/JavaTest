/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.po.Purchase;
import com.jdbc.po.Year;
import java.sql.Date;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface IPurchaseBiz {

    public List<Purchase> getByPurchase(String start, String end, String key);

    public List<Purchase> findAll();
    //采购入库

    public boolean purchasein(Object[][] purchases, Object[][] stocks);

    //采购退货
    public boolean purchasereturn(String purid,int proid,int returnnum,Date returntime,String returnreason);

    public boolean deletePurchase(int id);
    
    public List<Purchase> findSup(String start, String end, String key,String sort);
    
    public List<Year> getYear();
    //采购汇总
    public List<Purchase> getByPro(String start, String end);
    public List<Purchase> getBySup(String start, String end);
    public List<Purchase> getBySupAndPro(String start, String end);
    public List<Purchase> getByProAndSup(String start, String end);
}
