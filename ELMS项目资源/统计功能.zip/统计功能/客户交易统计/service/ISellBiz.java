/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.biz;

import com.jdbc.po.Sell;
import com.jdbc.po.Year;
import java.sql.Date;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ISellBiz {
    public List<Sell> findAll();
    public List<Sell> findByKey(String start,String end,String key);
    public boolean addSell(Object[][] purchases, Object[][] stocks);
    public boolean updateSell(String seid,int proid,int returnnum,Date returntime);
    public List<Sell> findByCusid(String start,String end);
    public List<Year> getYear();
    public List<Sell> getByEmp(String start,String end);
    public List<Sell> getByCusid(int cusid);
}
